from discord.ext.audiorec import AudioRecorder
from discord import VoiceClient

audio_recorder = AudioRecorder()

async def record_audio(ctx):
    """음성 채널에 연결하고 녹음을 시작합니다."""
    if ctx.author.voice:
        channel = ctx.author.voice.channel
        vc = await channel.connect()
        audio_recorder.start(vc)
        await ctx.send("녹음을 시작했습니다.")
    else:
        await ctx.send("음성 채널에 접속한 상태여야 녹음을 시작할 수 있습니다.")

async def stop_recording(ctx):
    """녹음을 종료하고 파일을 저장합니다."""
    if ctx.voice_client:
        audio_recorder.stop()
        recording_file = "recording.wav"
        audio_recorder.save(recording_file)
        await ctx.voice_client.disconnect()
        await ctx.send(f"녹음을 종료했습니다. 파일이 저장되었습니다: {recording_file}")
    else:
        await ctx.send("현재 녹음 중이 아닙니다.")
