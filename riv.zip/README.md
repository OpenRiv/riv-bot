DISCORD_TOKEN 프로젝트 루트 경로에 .env 파일 만들고 넣어주기(노션 참고)

#구현 기능

command
<br>
!회의- 회의 시작 및 종료 => 회의 녹음 기능 제공
