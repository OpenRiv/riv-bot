import openai
from pydub import AudioSegment
import os
import math

openai.api_key = os.getenv("OPENAI_API_KEY")

async def process_audio(file_path):
    audio = AudioSegment.from_file(file_path)
    chunk_size = 20 * 1024 * 1024
    duration_per_chunk = math.floor(chunk_size / (audio.frame_rate * audio.frame_width))

    chunks = [
        audio[i * duration_per_chunk * 1000 : (i + 1) * duration_per_chunk * 1000]
        for i in range(math.ceil(len(audio) / (duration_per_chunk * 1000)))
    ]

    transcribed_text = ""

    for i, chunk in enumerate(chunks):
        chunk_path = f"chunk_{i}.wav"
        chunk.export(chunk_path, format="wav")

        with open(chunk_path, "rb") as audio_file:
            response = openai.Audio.transcribe("whisper-1", audio_file)
            transcribed_text += response["text"] + "\\n"

        os.remove(chunk_path)

    return summarize_to_markdown(transcribed_text)

def summarize_to_markdown(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read()
        
        content = """
        1. Formal Conditions: Please write this text in the form of minutes in Korean.
        Please write it in detail to contain the decision-making process as much as possible.

        2. Result condition: Please write the final version in a markdown format.
        Markdown file should be .md.

        3. Speakers multi-indication condition: If you have multiple speakers, 
        please indicate the speaker in the same format as "A:", "B:", regardless of gender.
        However, if there is only one speaker, please omit it.

        4. Date of meeting : Please write based on the date of creation of the text file.
        """

        response = openai.ChatCompletion.create(
            model="gpt-4-turbo",
            messages=[
                {"role": "system", "content": content},
                {"role": "user", "content": text}
            ]
        )

        summary = response['choices'][0]['message']['content']
        markdown_file_path = file_path.replace('.txt', '_회의록.md')
        
        with open(markdown_file_path, "w", encoding="utf-8") as md_file:
            md_file.write(summary)
        
        return markdown_file_path
    except Exception as e:
        raise RuntimeError(f"Summary error: {e}")
